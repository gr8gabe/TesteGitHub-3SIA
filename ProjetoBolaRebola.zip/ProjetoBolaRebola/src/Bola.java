
public class Bola {
	private String cor;
	private double raio;

	public Bola(String cor, Double raio) {
		this.cor = cor;
		this.raio = raio;
	}

	public Bola maiorBola(Bola b1, Bola b2) {
		Bola aux = this;
		if (b1.raio > this.raio && b1.raio > b2.raio) {
			aux = b1;
		} else if (b2.raio > this.raio && b2.raio > b1.raio) {
			aux = b2;
		}
		return aux;
	}

	public String retornarDados() {
		return this.cor + " " + this.raio;
	}

	public String getCor() {
		return cor;
	}

	public void setCor(String cor) {
		this.cor = cor;
	}

	public double getRaio() {
		return raio;
	}

	public void setRaio(double raio) {
		this.raio = raio;
	}

}
