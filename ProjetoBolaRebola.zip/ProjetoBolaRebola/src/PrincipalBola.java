import javax.swing.JOptionPane;

public class PrincipalBola {
	public static void main(String args[]) {
		String cor;
		double raio;
		cor = JOptionPane.showInputDialog("Cor da bola 1");
		raio = Double.parseDouble(JOptionPane.showInputDialog("Raio da bola 1"));
		Bola bola1 = new Bola("azul",4.75);
		Bola bola2 = new Bola("branca",3.5);
		Bola bola3 = new Bola("vermelha",3.25);
		
		Bola aux = bola1.maiorBola(bola2,bola3);
		System.out.
		println("Dados da bola com o maior raio -> " + aux.retornarDados());
	}
}
